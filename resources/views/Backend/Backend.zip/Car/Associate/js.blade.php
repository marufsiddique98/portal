<script src="{{asset("js/jquery.dataTables.min.js")}}"></script>
<script src="{{asset("js/dataTables.bootstrap.min.js")}}"></script>
<script src="{{asset("js/dataTables.buttons.min.js")}}"></script>
<script src="{{asset("js/buttons.bootstrap.min.js")}}"></script>
<script src="{{asset("js/buttons.flash.min.js")}}"></script>
<script src="{{asset("js/buttons.html5.min.js")}}"></script>
<script src="{{asset("js/buttons.print.min.js")}}"></script>
<script src="{{asset("js/dataTables.fixedHeader.min.js")}}"></script>
<script src="{{asset("js/dataTables.keyTable.min.js")}}"></script>
<script src="{{asset("js/dataTables.responsive.min.js")}}"></script>
<script src="{{asset("js/responsive.bootstrap.js")}}"></script>
<script src="{{asset("js/dataTables.scroller.min.js")}}"></script>
{{--<script src="{{asset("js/szip.min.js")}}j"></script>--}}
<script src="{{asset("js/pdfmake.min.js")}}"></script>
<script src="{{asset("js/vfs_fonts.js")}}"></script>
{{--<script src="{{asset("js/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js")}}"></script>--}}
{{--<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>--}}

{{--datepicker--}}
{{--<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>--}}
{{--<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>--}}
{{--<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>--}}



