{{--Datatables CSS--}}
<link href=" {{asset("css/bootstrap-progressbar-3.3.4.min.css")}} " rel="stylesheet">

<link href="{{asset("css/dataTables.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/buttons.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/fixedHeader.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/responsive.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/scroller.bootstrap.min.css")}}" rel="stylesheet">
{{--<link href="{{asset("js/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css")}}" rel="stylesheet">--}}

{{--<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />--}}
